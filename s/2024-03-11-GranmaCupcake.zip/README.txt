The following characters are dressed for Hinamatsuri (https://en.wikipedia.org/wiki/Hinamatsuri):
	Tales of Hearts / Beryl Benito
	Tales of Vesperia / Estellise Sidos Heurassein


----


There are three Tales of the World: Radiant Mythology games, and each one has its own different Kanonno:
	https://aselia.fandom.com/wiki/Kanonno_(disambiguation)
There are images for all three characters in the bot currently under the single entry "Kanonno Grassvalley":
	Pasca Kanonno
		Spring '23
	Kanonno Earheart
		Summer '22
		Summer '23
	Kanonno Grassvalley
		Winter '21
		Winter '22
		Winter '23
There are Spring images for all three individually with the correct names in the Tales of the World: Radiant Mythology directory
I didn't create a different folder for each entry in the series since I figured it's probably easier to just keep them all under the main series