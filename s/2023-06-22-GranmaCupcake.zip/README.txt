I had previously tried submitting Katsuragi through someone else, but they came back to me and said that they weren't able to get her in because she was too NSFW or something. If that's the case, I would suggest the following images for consideration, which I would argue are equal or less covered:

Age of Ishtaria: Gilles de Rais (S22)
Destiny Child: Anemone (S22)
Destiny Child: Mercury
Girls' Frontline: DP-12 (F22)
High School DxD: Risa Gremory (W22)
How NOT To Summon a Demon Lord: Blue Receptionist
WIXOSS: Code Order Steak