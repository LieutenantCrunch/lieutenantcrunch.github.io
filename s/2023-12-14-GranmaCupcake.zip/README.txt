Tales of Xillia
	The title of Milla Maxwell's image is "New Year's Bath", the same as Tales of Vesperia: Rita Mordio Winter 2022