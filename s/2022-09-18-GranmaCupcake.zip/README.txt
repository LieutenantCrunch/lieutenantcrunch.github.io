Shantae
	Brandon is dressed as a spoof on He-man (referenced as "Bran-son" in the game)
	Shantae, Rottytops, Sky, and Risky Boots are all dressed as spoofs of Princess Leia (referenced as "Space Princess" in the game)

One-Punch Man
	All of these images came from an official Happy Halloween wallpaper; the highest res was 1920x1080
	Need to check whether Puri-Puri Prisoner will pass SFW requirements

Tales of Zestiria
	I am aware that there is some "fancier" Halloween art (has gradients and all that crap) for Edna that is currently used for Karuta's E4 image. However, she's my favorite 2D character and I far prefer the picture I used here, so please use this image and not the one Karuta uses.