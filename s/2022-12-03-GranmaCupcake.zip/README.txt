Tales of Vesperia
	The title of Rita Mordio's image is "New Year's Bath"
Squid Girl
	There is an alternate image for Ika Musume in the _ALTERNATE_ folder if you don't like the one in the main folder