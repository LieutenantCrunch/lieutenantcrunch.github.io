I still have the source images for all pictures, and I have alternate images for some of the characters if a different crop is desired or a different picture or whatever. All images are official.



--- Doujin ---

Doujin is sort of an expansion on a suggestion I previously made (#1903) so instead of "Doujin Vocalist", it's just "Doujin" now. Here's a definition of what Doujin means: https://en.wikipedia.org/wiki/Doujin . The characters in this directory are primarily vocalists and are similar to the existing "Utaite" series (many of them are IRL friends with some of the Utaite), but these vocalists do not fall under the Utaite category. Camellia is a composer often associated with Nanahira (currently in Tofu in the Utaite series). By switching to "Doujin" from "Doujin Vocalists", it makes it more flexible so more can be added later. Here's a definition of Utaite to clear things up a bit: https://utaite.fandom.com/wiki/Utaite .


--- Shantae ---

Originally Egg had marked these as being worked on, then it was blanked out. I then contacted emina and said I would process all of the images and produced all of these and provided emina with this page: https://lieutenantcrunch.github.io/s/Shantae/ . I have not heard back from emina since and they are still on the spreadsheet (#2298) listed as nobody working on them, so that is why I have included them in this zip.


--- SU22 ---

While not -officially- announced, I know the submissions team starts working on event pictures well ahead of time, so I wanted to get these in early.


--- Tales of Berseria, Tales of Hearts, Tales of Innocence ---

These includes characters that are currently missing from series that are currently in Tofu. All but two of the characters in these directories are also in the SU22 directory, and the last I heard there was a bug adding E1 for characters after they had event versions added, so I wanted to make sure their E1s got in before SU22 versions were added.